export type PlatformType = 'instagram' | 'whatsapp' | 'telegram';

export type Language = 'fa' | 'en';

export interface ShortcutItem {
  id: string;
  title: string;
  platform: PlatformType;
  target: string; // phone number, username, or profile
  note?: string;
  createdAt: number;
}

export interface PlatformInfo {
  id: PlatformType;
  name: string;
  persianName: string;
  color: string;
  bgGradient: string;
  accentColor: string;
  webUrl: string;
  appProtocol: string;
  descriptionFa: string;
  descriptionEn: string;
}
