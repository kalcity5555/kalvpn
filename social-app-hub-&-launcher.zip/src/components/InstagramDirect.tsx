import React, { useState } from 'react';
import { Language, ShortcutItem } from '../types';
import { translations } from '../data/translations';
import { InstagramIcon } from './BrandIcons';
import { AtSign, ExternalLink, QrCode, Copy, Bookmark, Check, Sparkles, Film, Compass, Hash } from 'lucide-react';

interface InstagramDirectProps {
  language: Language;
  onShowQR: (url: string, title: string) => void;
  onAddShortcut: (shortcut: Omit<ShortcutItem, 'id' | 'createdAt'>) => void;
  onShowToast: (msg: string) => void;
}

export function InstagramDirect({
  language,
  onShowQR,
  onAddShortcut,
  onShowToast,
}: InstagramDirectProps) {
  const t = translations[language];

  const [username, setUsername] = useState('');
  const [hashtag, setHashtag] = useState('');
  const [copied, setCopied] = useState(false);

  const cleanUser = username.trim().replace(/^@/, '');
  const cleanHash = hashtag.trim().replace(/^#/, '');

  const igProfileUrl = cleanUser ? `https://instagram.com/${cleanUser}` : 'https://instagram.com';
  const igHashtagUrl = cleanHash ? `https://instagram.com/explore/tags/${cleanHash}` : '';
  const igReelsUrl = 'https://instagram.com/reels';
  const igExploreUrl = 'https://instagram.com/explore';

  const handleCopyLink = () => {
    if (!cleanUser && !cleanHash) {
      onShowToast(t.enterValidInput);
      return;
    }
    const targetUrl = cleanHash ? igHashtagUrl : igProfileUrl;
    navigator.clipboard.writeText(targetUrl);
    setCopied(true);
    onShowToast(t.linkCopied);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSaveShortcut = () => {
    if (!cleanUser && !cleanHash) {
      onShowToast(t.enterValidInput);
      return;
    }
    onAddShortcut({
      platform: 'instagram',
      title: cleanHash ? `#${cleanHash}` : `@${cleanUser}`,
      target: cleanHash ? `explore/tags/${cleanHash}` : cleanUser,
    });
    onShowToast(t.savedSuccessfully);
  };

  return (
    <div className="bg-slate-900/90 rounded-2xl border border-pink-500/30 p-6 shadow-2xl backdrop-blur-md">
      
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-yellow-500 via-pink-500 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-pink-500/20">
          <InstagramIcon className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <span>{t.igTitle}</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {t.igDesc}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Form */}
        <div className="lg:col-span-7 space-y-4">
          
          {/* Username Input */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">
              نام کاربری اینستاگرام (Username)
            </label>
            <div className="relative">
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder={t.igUserPlaceholder}
                className="w-full bg-slate-800 text-white text-sm rounded-xl px-4 py-3 pl-10 border border-slate-700 focus:outline-none focus:ring-2 focus:ring-pink-500 placeholder-slate-500 dir-ltr"
              />
              <AtSign className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
            </div>
          </div>

          {/* Hashtag Input */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">
              جستجوی هشتگ (Hashtag Search)
            </label>
            <div className="relative">
              <input
                type="text"
                value={hashtag}
                onChange={(e) => setHashtag(e.target.value)}
                placeholder="مثلا photography یا travel"
                className="w-full bg-slate-800 text-white text-sm rounded-xl px-4 py-3 pl-10 border border-slate-700 focus:outline-none focus:ring-2 focus:ring-pink-500 placeholder-slate-500 dir-ltr"
              />
              <Hash className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
            <a
              href={cleanHash ? igHashtagUrl : igProfileUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:flex-1 flex items-center justify-center gap-2 py-3 px-5 rounded-xl font-bold text-sm bg-gradient-to-r from-amber-500 via-rose-500 to-purple-600 hover:opacity-95 text-white shadow-lg shadow-pink-500/25 transition-all"
            >
              <ExternalLink className="w-4 h-4" />
              <span>{t.openProfile}</span>
            </a>

            <button
              onClick={handleSaveShortcut}
              disabled={!cleanUser && !cleanHash}
              className="w-full sm:w-auto flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-pink-400 border border-slate-700 text-xs font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Bookmark className="w-4 h-4" />
              <span>{t.save}</span>
            </button>
          </div>

          {/* Quick Instagram Sections */}
          <div className="pt-2 border-t border-slate-800/80">
            <span className="text-xs font-semibold text-slate-400 block mb-2">
              بخش‌های محبوب اینستاگرام:
            </span>
            <div className="grid grid-cols-2 gap-2">
              <a
                href={igReelsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 py-2 px-3 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700/60 transition-colors"
              >
                <Film className="w-4 h-4 text-pink-400" />
                <span>{t.openReels}</span>
              </a>

              <a
                href={igExploreUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 py-2 px-3 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700/60 transition-colors"
              >
                <Compass className="w-4 h-4 text-purple-400" />
                <span>{t.openExplore}</span>
              </a>
            </div>
          </div>

        </div>

        {/* Right Info */}
        <div className="lg:col-span-5 bg-slate-950/60 rounded-xl p-5 border border-slate-800 flex flex-col justify-between">
          <div>
            <span className="text-[11px] font-semibold text-pink-400 uppercase tracking-wider block mb-2">
              لینک مستقیم (Instagram URL)
            </span>

            <div className="bg-slate-900 rounded-xl p-3 border border-slate-800 text-xs text-pink-300 font-mono break-all min-h-[60px] flex items-center dir-ltr">
              {cleanHash ? igHashtagUrl : igProfileUrl}
            </div>

            <div className="mt-4 space-y-2 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-pink-500"></span>
                <span>هدف: <strong className="text-white dir-ltr inline-block">{cleanHash ? `#${cleanHash}` : `@${cleanUser || '---'}`}</strong></span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 mt-6">
            <button
              onClick={handleCopyLink}
              className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-pink-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
              <span>{copied ? 'کپی شد' : t.copyLink}</span>
            </button>

            <button
              onClick={() => onShowQR(cleanHash ? igHashtagUrl : igProfileUrl, `اینستاگرام (${cleanHash ? `#${cleanHash}` : `@${cleanUser}`})`)}
              className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-colors"
            >
              <QrCode className="w-3.5 h-3.5 text-slate-400" />
              <span>{t.showQR}</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
}
