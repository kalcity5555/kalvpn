import React, { useState } from 'react';
import { Language, ShortcutItem } from '../types';
import { translations, countryCodes } from '../data/translations';
import { WhatsAppIcon } from './BrandIcons';
import { Phone, MessageSquare, ExternalLink, QrCode, Copy, Bookmark, Check, Smartphone, Sparkles, Send } from 'lucide-react';

interface WhatsAppDirectChatProps {
  language: Language;
  onShowQR: (url: string, title: string) => void;
  onAddShortcut: (shortcut: Omit<ShortcutItem, 'id' | 'createdAt'>) => void;
  onShowToast: (msg: string) => void;
}

export function WhatsAppDirectChat({
  language,
  onShowQR,
  onAddShortcut,
  onShowToast,
}: WhatsAppDirectChatProps) {
  const t = translations[language];

  const [selectedCountryCode, setSelectedCountryCode] = useState('+98');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [copied, setCopied] = useState(false);

  // Quick message presets
  const presets = language === 'fa' 
    ? ['سلام، وقت بخیر', 'درخواست اطلاعات بیشتر', 'ارسال کاتالوگ', 'با تشکر از شما']
    : ['Hello, hope you are well', 'Request for information', 'Thank you!', 'Can we chat?'];

  // Format phone number
  const cleanNumber = (num: string, code: string) => {
    let clean = num.replace(/\D/g, ''); // remove non-digits
    if (clean.startsWith('0')) {
      clean = clean.substring(1);
    }
    const codeNum = code.replace('+', '');
    if (clean.startsWith(codeNum)) {
      return clean;
    }
    return `${codeNum}${clean}`;
  };

  const formattedPhone = cleanNumber(phone, selectedCountryCode);
  const waUrl = formattedPhone 
    ? `https://wa.me/${formattedPhone}${message ? `?text=${encodeURIComponent(message)}` : ''}` 
    : '';

  const handleCopyLink = () => {
    if (!waUrl) {
      onShowToast(t.enterValidInput);
      return;
    }
    navigator.clipboard.writeText(waUrl);
    setCopied(true);
    onShowToast(t.linkCopied);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleOpenChat = () => {
    if (!formattedPhone || formattedPhone.length < 7) {
      onShowToast(t.enterValidInput);
      return;
    }
    window.open(waUrl, '_blank');
  };

  const handleSaveShortcut = () => {
    if (!formattedPhone) {
      onShowToast(t.enterValidInput);
      return;
    }
    onAddShortcut({
      platform: 'whatsapp',
      title: phone || formattedPhone,
      target: formattedPhone,
      note: message || undefined,
    });
    onShowToast(t.savedSuccessfully);
  };

  return (
    <div className="bg-slate-900/90 rounded-2xl border border-emerald-500/30 p-6 shadow-2xl backdrop-blur-md">
      
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-2xl bg-emerald-500 flex items-center justify-center text-white shadow-lg shadow-emerald-500/20">
          <WhatsAppIcon className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <span>{t.waTitle}</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {t.waDesc}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Input Form */}
        <div className="lg:col-span-7 space-y-4">
          
          {/* Phone Input with Country Code */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">
              {t.countryCode} & {t.shortcutTarget}
            </label>
            <div className="flex gap-2">
              <select
                value={selectedCountryCode}
                onChange={(e) => setSelectedCountryCode(e.target.value)}
                className="bg-slate-800 text-white text-xs sm:text-sm rounded-xl px-3 py-3 border border-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 shrink-0"
              >
                {countryCodes.map((c) => (
                  <option key={c.code} value={c.code}>
                    {c.flag} {c.code} ({c.country})
                  </option>
                ))}
              </select>

              <div className="relative flex-1">
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder={t.phonePlaceholder}
                  className="w-full bg-slate-800 text-white text-sm rounded-xl px-4 py-3 pl-10 border border-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 placeholder-slate-500 dir-ltr"
                />
                <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
              </div>
            </div>
          </div>

          {/* Message Textarea */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">
              {t.messagePlaceholder}
            </label>
            <div className="relative">
              <textarea
                rows={3}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder={t.messagePlaceholder}
                className="w-full bg-slate-800 text-white text-sm rounded-xl px-4 py-3 border border-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500 placeholder-slate-500 resize-none"
              />
            </div>

            {/* Message Presets */}
            <div className="flex flex-wrap gap-1.5 mt-2">
              {presets.map((preset, idx) => (
                <button
                  key={idx}
                  onClick={() => setMessage(preset)}
                  className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-slate-700/60 transition-colors"
                >
                  + {preset}
                </button>
              ))}
            </div>
          </div>

          {/* Main Launch Actions */}
          <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
            <button
              onClick={handleOpenChat}
              disabled={!phone}
              className={`w-full sm:flex-1 flex items-center justify-center gap-2 py-3 px-5 rounded-xl font-bold text-sm transition-all shadow-lg ${
                phone
                  ? 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-emerald-500/25 cursor-pointer'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
              }`}
            >
              <Send className="w-4 h-4" />
              <span>{t.startChat}</span>
            </button>

            <button
              onClick={handleSaveShortcut}
              disabled={!phone}
              className="w-full sm:w-auto flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 text-xs font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              title="ذخیره میانبر"
            >
              <Bookmark className="w-4 h-4" />
              <span>{t.save}</span>
            </button>
          </div>

        </div>

        {/* Live Preview & Link Utilities */}
        <div className="lg:col-span-5 bg-slate-950/60 rounded-xl p-5 border border-slate-800 flex flex-col justify-between">
          <div>
            <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider block mb-2">
              لینک تولید شده (Generated Link)
            </span>

            <div className="bg-slate-900 rounded-xl p-3 border border-slate-800 text-xs text-emerald-300 font-mono break-all min-h-[60px] flex items-center">
              {waUrl || 'https://wa.me/...'}
            </div>

            <div className="mt-4 space-y-2 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                <span>شماره هدف: <strong className="text-white dir-ltr inline-block">{formattedPhone || '---'}</strong></span>
              </div>
              {message && (
                <div className="flex items-start gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 mt-1"></span>
                  <span>پیام: <span className="text-slate-200 line-clamp-2">{message}</span></span>
                </div>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 mt-6">
            <button
              onClick={handleCopyLink}
              disabled={!waUrl}
              className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-colors disabled:opacity-50"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
              <span>{copied ? 'کپی شد' : t.copyLink}</span>
            </button>

            <button
              onClick={() => waUrl && onShowQR(waUrl, `واتساپ (${formattedPhone})`)}
              disabled={!waUrl}
              className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-colors disabled:opacity-50"
            >
              <QrCode className="w-3.5 h-3.5 text-slate-400" />
              <span>{t.showQR}</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
}
