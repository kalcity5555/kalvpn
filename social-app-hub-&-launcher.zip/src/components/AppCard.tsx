import React from 'react';
import { PlatformType, Language } from '../types';
import { translations } from '../data/translations';
import { InstagramIcon, WhatsAppIcon, TelegramIcon } from './BrandIcons';
import { ExternalLink, Smartphone, MessageSquare, ArrowRight, Zap, Sparkles, CheckCircle2 } from 'lucide-react';

interface AppCardProps {
  platform: PlatformType;
  language: Language;
  onOpenTool: (platform: PlatformType) => void;
}

export function AppCard({ platform, language, onOpenTool }: AppCardProps) {
  const t = translations[language];

  const platformData = {
    whatsapp: {
      name: t.whatsapp,
      icon: WhatsAppIcon,
      color: 'from-emerald-500 via-teal-500 to-green-600',
      badgeBg: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
      btnBg: 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-emerald-500/20',
      borderColor: 'border-emerald-500/30 hover:border-emerald-500/60',
      glowColor: 'group-hover:shadow-emerald-500/10',
      webUrl: 'https://web.whatsapp.com',
      appProtocol: 'whatsapp://',
      desc: language === 'fa' 
        ? 'ارسال پیام مستقیم به شماره دلخواه بدون نیاز به ذخیره در مخاطبین، پشتیبانی از واتساپ وب و اپلیکیشن موبایل'
        : 'Direct messaging without saving contacts, WhatsApp Web, and native app deep links.',
      featuresFa: ['ارسال پیام مستقیم بدون ذخیره مخاطب', 'پشتیبانی از واتساپ وب', 'ایجاد QR کد اختصاصی چت'],
      featuresEn: ['Direct message without saving contact', 'WhatsApp Web launcher', 'Custom chat QR code generator']
    },
    telegram: {
      name: t.telegram,
      icon: TelegramIcon,
      color: 'from-sky-500 via-blue-500 to-indigo-600',
      badgeBg: 'bg-sky-500/10 text-sky-400 border-sky-500/20',
      btnBg: 'bg-sky-500 hover:bg-sky-600 text-white shadow-sky-500/20',
      borderColor: 'border-sky-500/30 hover:border-sky-500/60',
      glowColor: 'group-hover:shadow-sky-500/10',
      webUrl: 'https://web.telegram.org',
      appProtocol: 'tg://',
      desc: language === 'fa'
        ? 'جستجوی سریع آیدی، کانال، گروه و ربات‌های تلگرام، ورود به نسخه وب A/K و اپلیکیشن دسکتاپ/موبایل'
        : 'Instant Telegram username & channel lookup, Web version A/K launcher, and native app deep links.',
      featuresFa: ['جستجوی مستقیم آیدی و کانال', 'ورود به نسخه وب A و K', 'اشتراک‌گذاری سریع لینک'],
      featuresEn: ['Direct username & channel search', 'Web version A & K access', 'Quick message link share']
    },
    instagram: {
      name: t.instagram,
      icon: InstagramIcon,
      color: 'from-amber-500 via-rose-500 to-purple-600',
      badgeBg: 'bg-pink-500/10 text-pink-400 border-pink-500/20',
      btnBg: 'bg-gradient-to-r from-amber-500 via-rose-500 to-purple-600 hover:opacity-90 text-white shadow-pink-500/20',
      borderColor: 'border-pink-500/30 hover:border-pink-500/60',
      glowColor: 'group-hover:shadow-pink-500/10',
      webUrl: 'https://instagram.com',
      appProtocol: 'instagram://',
      desc: language === 'fa'
        ? 'مشاهده سریع پروفایل کاربران، باز کردن ریلز (Reels)، اکسپلور و ورود مستقیم به وب‌سایت و اپلیکیشن'
        : 'Quick profile lookup, Reels launcher, Explore section, and mobile app deep links.',
      featuresFa: ['مشاهده مستقیم پروفایل با آیدی', 'دسترسی به بخش ریلز و اکسپلور', 'پشتیبانی از اینستاگرام وب'],
      featuresEn: ['Direct profile lookup by username', 'Instant Reels & Explore access', 'Instagram Web compatibility']
    }
  };

  const info = platformData[platform];
  const Icon = info.icon;
  const features = language === 'fa' ? info.featuresFa : info.featuresEn;

  return (
    <div className={`group relative bg-slate-900/90 rounded-2xl border ${info.borderColor} p-6 shadow-xl transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl ${info.glowColor} flex flex-col justify-between`}>
      
      {/* Top Header */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-2xl bg-gradient-to-tr ${info.color} flex items-center justify-center text-white shadow-lg`}>
              <Icon className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white group-hover:text-slate-100">
                {info.name}
              </h3>
              <span className={`inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full border ${info.badgeBg}`}>
                <Zap className="w-3 h-3" />
                Active Hub
              </span>
            </div>
          </div>
        </div>

        <p className="text-slate-300 text-sm leading-relaxed mb-5">
          {info.desc}
        </p>

        {/* Feature bullets */}
        <div className="space-y-2 mb-6">
          {features.map((item, idx) => (
            <div key={idx} className="flex items-center gap-2 text-xs text-slate-400">
              <CheckCircle2 className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              <span>{item}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="space-y-2.5 pt-4 border-t border-slate-800/80">
        <button
          onClick={() => onOpenTool(platform)}
          className={`w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl font-semibold text-sm transition-all shadow-md ${info.btnBg}`}
        >
          <Sparkles className="w-4 h-4" />
          <span>{t.launchApp} ({info.name})</span>
        </button>

        <div className="grid grid-cols-2 gap-2">
          <a
            href={info.webUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700/80 transition-colors"
          >
            <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
            <span>{t.openWeb}</span>
          </a>

          <a
            href={info.appProtocol}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700/80 transition-colors"
          >
            <Smartphone className="w-3.5 h-3.5 text-slate-400" />
            <span>{t.openNative}</span>
          </a>
        </div>
      </div>
    </div>
  );
}
