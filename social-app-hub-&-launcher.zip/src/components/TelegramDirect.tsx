import React, { useState } from 'react';
import { Language, ShortcutItem } from '../types';
import { translations } from '../data/translations';
import { TelegramIcon } from './BrandIcons';
import { AtSign, ExternalLink, QrCode, Copy, Bookmark, Check, Send, Sparkles, MessageSquare } from 'lucide-react';

interface TelegramDirectProps {
  language: Language;
  onShowQR: (url: string, title: string) => void;
  onAddShortcut: (shortcut: Omit<ShortcutItem, 'id' | 'createdAt'>) => void;
  onShowToast: (msg: string) => void;
}

export function TelegramDirect({
  language,
  onShowQR,
  onAddShortcut,
  onShowToast,
}: TelegramDirectProps) {
  const t = translations[language];

  const [username, setUsername] = useState('');
  const [shareText, setShareText] = useState('');
  const [copied, setCopied] = useState(false);

  // Clean username (remove leading @ if user inputs it)
  const cleanUser = username.trim().replace(/^@/, '');

  const tgWebUrl = cleanUser ? `https://t.me/${cleanUser}` : '';
  const tgAppProtocol = cleanUser ? `tg://resolve?domain=${cleanUser}` : '';
  const tgShareUrl = shareText 
    ? `https://t.me/share/url?url=${encodeURIComponent(tgWebUrl || 'https://t.me')}&text=${encodeURIComponent(shareText)}`
    : '';

  const handleOpenTelegram = (protocol: boolean = false) => {
    if (!cleanUser) {
      onShowToast(t.enterValidInput);
      return;
    }
    window.open(protocol ? tgAppProtocol : tgWebUrl, '_blank');
  };

  const handleCopyLink = () => {
    if (!tgWebUrl) {
      onShowToast(t.enterValidInput);
      return;
    }
    navigator.clipboard.writeText(tgWebUrl);
    setCopied(true);
    onShowToast(t.linkCopied);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSaveShortcut = () => {
    if (!cleanUser) {
      onShowToast(t.enterValidInput);
      return;
    }
    onAddShortcut({
      platform: 'telegram',
      title: `@${cleanUser}`,
      target: cleanUser,
    });
    onShowToast(t.savedSuccessfully);
  };

  return (
    <div className="bg-slate-900/90 rounded-2xl border border-sky-500/30 p-6 shadow-2xl backdrop-blur-md">
      
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 rounded-2xl bg-sky-500 flex items-center justify-center text-white shadow-lg shadow-sky-500/20">
          <TelegramIcon className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <span>{t.tgTitle}</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {t.tgDesc}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Form */}
        <div className="lg:col-span-7 space-y-4">
          
          {/* Username Input */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">
              {t.channelOrUser}
            </label>
            <div className="relative">
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder={t.usernamePlaceholder}
                className="w-full bg-slate-800 text-white text-sm rounded-xl px-4 py-3 pl-10 border border-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-500 placeholder-slate-500 dir-ltr"
              />
              <AtSign className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
            </div>
          </div>

          {/* Share Text Generator (Optional) */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">
              متن اشتراک‌گذاری اختیاری (Share Message)
            </label>
            <input
              type="text"
              value={shareText}
              onChange={(e) => setShareText(e.target.value)}
              placeholder="متنی که می‌خواهید در تلگرام به اشتراک بگذارید..."
              className="w-full bg-slate-800 text-white text-sm rounded-xl px-4 py-3 border border-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-500 placeholder-slate-500"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
            <button
              onClick={() => handleOpenTelegram(false)}
              disabled={!cleanUser}
              className={`w-full sm:flex-1 flex items-center justify-center gap-2 py-3 px-5 rounded-xl font-bold text-sm transition-all shadow-lg ${
                cleanUser
                  ? 'bg-sky-500 hover:bg-sky-600 text-white shadow-sky-500/25 cursor-pointer'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
              }`}
            >
              <Send className="w-4 h-4" />
              <span>{t.openTelegram}</span>
            </button>

            <button
              onClick={handleSaveShortcut}
              disabled={!cleanUser}
              className="w-full sm:w-auto flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-sky-400 border border-slate-700 text-xs font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Bookmark className="w-4 h-4" />
              <span>{t.save}</span>
            </button>
          </div>

        </div>

        {/* Right Info & QR */}
        <div className="lg:col-span-5 bg-slate-950/60 rounded-xl p-5 border border-slate-800 flex flex-col justify-between">
          <div>
            <span className="text-[11px] font-semibold text-sky-400 uppercase tracking-wider block mb-2">
              لینک مستقیم (Telegram Link)
            </span>

            <div className="bg-slate-900 rounded-xl p-3 border border-slate-800 text-xs text-sky-300 font-mono break-all min-h-[60px] flex items-center dir-ltr">
              {tgWebUrl || 'https://t.me/...'}
            </div>

            <div className="mt-4 space-y-2 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-sky-500"></span>
                <span>آیدی هدف: <strong className="text-white dir-ltr inline-block">@{cleanUser || '---'}</strong></span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-sky-500"></span>
                <span>پروتکل اپلیکیشن: <span className="text-slate-300 dir-ltr inline-block">{tgAppProtocol || 'tg://...'}</span></span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 mt-6">
            <button
              onClick={handleCopyLink}
              disabled={!tgWebUrl}
              className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-colors disabled:opacity-50"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-sky-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
              <span>{copied ? 'کپی شد' : t.copyLink}</span>
            </button>

            <button
              onClick={() => tgWebUrl && onShowQR(tgWebUrl, `تلگرام (@${cleanUser})`)}
              disabled={!tgWebUrl}
              className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition-colors disabled:opacity-50"
            >
              <QrCode className="w-3.5 h-3.5 text-slate-400" />
              <span>{t.showQR}</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
}
