import React from 'react';
import { Language } from '../types';
import { translations } from '../data/translations';
import { InstagramIcon, WhatsAppIcon, TelegramIcon } from './BrandIcons';
import { Globe, Sparkles, Bookmark, Compass, LayoutDashboard, ExternalLink } from 'lucide-react';

interface HeaderProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  shortcutCount: number;
}

export function Header({
  language,
  onLanguageChange,
  activeTab,
  setActiveTab,
  shortcutCount,
}: HeaderProps) {
  const t = translations[language];

  const navTabs = [
    { id: 'dashboard', label: t.tabDashboard, icon: LayoutDashboard },
    { id: 'whatsapp', label: t.tabWhatsapp, icon: WhatsAppIcon, isBrand: true, color: 'text-emerald-500' },
    { id: 'telegram', label: t.tabTelegram, icon: TelegramIcon, isBrand: true, color: 'text-sky-500' },
    { id: 'instagram', label: t.tabInstagram, icon: InstagramIcon, isBrand: true, color: 'text-pink-500' },
    { id: 'shortcuts', label: `${t.tabShortcuts} (${shortcutCount})`, icon: Bookmark },
    { id: 'webview', label: t.tabWebview, icon: Compass },
  ];

  return (
    <header className="sticky top-0 z-30 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 text-white shadow-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo & Brand Title */}
          <div className="flex items-center gap-3">
            <div className="flex items-center -space-x-2 space-x-reverse">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 flex items-center justify-center shadow-lg shadow-pink-500/20 text-white">
                <InstagramIcon className="w-5 h-5" />
              </div>
              <div className="w-10 h-10 rounded-xl bg-emerald-500 flex items-center justify-center shadow-lg shadow-emerald-500/20 text-white ring-2 ring-slate-900">
                <WhatsAppIcon className="w-5 h-5" />
              </div>
              <div className="w-10 h-10 rounded-xl bg-sky-500 flex items-center justify-center shadow-lg shadow-sky-500/20 text-white ring-2 ring-slate-900">
                <TelegramIcon className="w-5 h-5" />
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-300 bg-clip-text text-transparent">
                  {t.appTitle}
                </h1>
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  Ready
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">
                {t.appSubtitle}
              </p>
            </div>
          </div>

          {/* Right Tools: Language Toggle & Quick External Links */}
          <div className="flex items-center gap-3">
            {/* Quick Web Launches */}
            <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-800/80 border border-slate-700/60 text-xs">
              <span className="text-slate-400">{t.openWeb}:</span>
              <a
                href="https://web.whatsapp.com"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-emerald-400 transition-colors font-medium text-slate-200"
              >
                WhatsApp
              </a>
              <span className="text-slate-600">•</span>
              <a
                href="https://web.telegram.org"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-sky-400 transition-colors font-medium text-slate-200"
              >
                Telegram
              </a>
              <span className="text-slate-600">•</span>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-pink-400 transition-colors font-medium text-slate-200"
              >
                Instagram
              </a>
            </div>

            {/* Language Switcher */}
            <button
              onClick={() => onLanguageChange(language === 'fa' ? 'en' : 'fa')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700/70 text-xs font-semibold transition-all"
              title="Change Language / تغییر زبان"
            >
              <Globe className="w-3.5 h-3.5 text-slate-400" />
              <span>{language === 'fa' ? 'English' : 'فارسی'}</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto py-2 no-scrollbar border-t border-slate-800/80">
          {navTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-medium whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-slate-800 text-white shadow-sm ring-1 ring-slate-700'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                <Icon className={`w-4 h-4 ${tab.isBrand ? tab.color : isActive ? 'text-indigo-400' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
}
