import React from 'react';
import { X, Download, ExternalLink, QrCode } from 'lucide-react';

interface QRCodeModalProps {
  url: string;
  title: string;
  onClose: () => void;
}

export function QRCodeModal({ url, title, onClose }: QRCodeModalProps) {
  if (!url) return null;

  const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(url)}&margin=10`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-sm w-full shadow-2xl text-center relative">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 left-4 text-slate-400 hover:text-white p-1 rounded-lg bg-slate-800 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center mx-auto mb-3">
          <QrCode className="w-6 h-6" />
        </div>

        <h3 className="text-lg font-bold text-white mb-1">
          QR کد اختصاصی
        </h3>
        <p className="text-xs text-slate-400 mb-4 line-clamp-1">
          {title}
        </p>

        {/* QR Image Box */}
        <div className="bg-white p-4 rounded-xl shadow-inner inline-block mb-4">
          <img
            src={qrImageUrl}
            alt="QR Code"
            className="w-48 h-48 object-contain mx-auto"
          />
        </div>

        <p className="text-xs text-slate-400 mb-5 break-all dir-ltr bg-slate-950/80 p-2 rounded-lg border border-slate-800 font-mono">
          {url}
        </p>

        <div className="grid grid-cols-2 gap-2">
          <a
            href={qrImageUrl}
            download="qrcode.png"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>دانلود QR</span>
          </a>

          <a
            href={url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>باز کردن لینک</span>
          </a>
        </div>

      </div>
    </div>
  );
}
