import React, { useState } from 'react';
import { ShortcutItem, Language } from '../types';
import { translations } from '../data/translations';
import { InstagramIcon, WhatsAppIcon, TelegramIcon } from './BrandIcons';
import { Bookmark, Trash2, ExternalLink, QrCode, Plus, Search, Send, Smartphone } from 'lucide-react';

interface ShortcutManagerProps {
  shortcuts: ShortcutItem[];
  language: Language;
  onRemoveShortcut: (id: string) => void;
  onShowQR: (url: string, title: string) => void;
  onShowToast: (msg: string) => void;
}

export function ShortcutManager({
  shortcuts,
  language,
  onRemoveShortcut,
  onShowQR,
  onShowToast,
}: ShortcutManagerProps) {
  const t = translations[language];
  const [filter, setFilter] = useState<string>('all');
  const [search, setSearch] = useState('');

  const filteredShortcuts = shortcuts.filter((s) => {
    const matchesFilter = filter === 'all' || s.platform === filter;
    const matchesSearch = s.title.toLowerCase().includes(search.toLowerCase()) || 
                          s.target.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const getPlatformIcon = (platform: string) => {
    switch (platform) {
      case 'whatsapp':
        return <WhatsAppIcon className="w-5 h-5 text-emerald-400" />;
      case 'telegram':
        return <TelegramIcon className="w-5 h-5 text-sky-400" />;
      case 'instagram':
        return <InstagramIcon className="w-5 h-5 text-pink-400" />;
      default:
        return <Bookmark className="w-5 h-5 text-amber-400" />;
    }
  };

  const getPlatformUrl = (shortcut: ShortcutItem) => {
    switch (shortcut.platform) {
      case 'whatsapp':
        return `https://wa.me/${shortcut.target}${shortcut.note ? `?text=${encodeURIComponent(shortcut.note)}` : ''}`;
      case 'telegram':
        return `https://t.me/${shortcut.target.replace(/^@/, '')}`;
      case 'instagram':
        return shortcut.target.startsWith('explore/') 
          ? `https://instagram.com/${shortcut.target}` 
          : `https://instagram.com/${shortcut.target.replace(/^@/, '')}`;
      default:
        return '#';
    }
  };

  const handleLaunch = (shortcut: ShortcutItem) => {
    const url = getPlatformUrl(shortcut);
    window.open(url, '_blank');
  };

  return (
    <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-2xl backdrop-blur-md">
      
      {/* Top Header & Search/Filter Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Bookmark className="w-5 h-5 text-indigo-400" />
            <span>{t.shortcuts}</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            میانبرهای ذخیره‌شده شما برای دسترسی سریع‌تر در یک کلیک
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
          {['all', 'whatsapp', 'telegram', 'instagram'].map((p) => (
            <button
              key={p}
              onClick={() => setFilter(p)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold capitalize transition-all ${
                filter === p
                  ? 'bg-slate-800 text-white ring-1 ring-slate-700 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              {p === 'all' ? t.allPlatforms : p}
            </button>
          ))}
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative mb-6">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="جستجو در میانبرها..."
          className="w-full bg-slate-800 text-white text-sm rounded-xl px-4 py-2.5 pl-10 border border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-slate-500"
        />
        <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
      </div>

      {/* Shortcuts List */}
      {filteredShortcuts.length === 0 ? (
        <div className="text-center py-12 border border-dashed border-slate-800 rounded-2xl bg-slate-950/40">
          <Bookmark className="w-10 h-10 text-slate-600 mx-auto mb-3" />
          <p className="text-slate-400 text-sm font-medium">{t.noShortcuts}</p>
          <p className="text-slate-500 text-xs mt-1">
            می‌توانید از بخش ابزار هر شبکه اجتماعی مخاطبین یا کانال‌های مورد نظر خود را ذخیره کنید.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredShortcuts.map((shortcut) => {
            const url = getPlatformUrl(shortcut);
            return (
              <div
                key={shortcut.id}
                className="bg-slate-800/80 rounded-xl p-4 border border-slate-700/70 hover:border-slate-600 transition-all flex flex-col justify-between gap-3 group"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                      {getPlatformIcon(shortcut.platform)}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors">
                        {shortcut.title}
                      </h4>
                      <p className="text-xs text-slate-400 dir-ltr text-right">
                        {shortcut.target}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      onRemoveShortcut(shortcut.id);
                      onShowToast(t.deletedSuccessfully);
                    }}
                    className="text-slate-500 hover:text-rose-400 transition-colors p-1"
                    title={t.delete}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                {shortcut.note && (
                  <p className="text-xs text-slate-400 bg-slate-900/60 p-2 rounded-lg border border-slate-800/80 line-clamp-2">
                    {shortcut.note}
                  </p>
                )}

                <div className="flex items-center gap-2 pt-2 border-t border-slate-700/50">
                  <button
                    onClick={() => handleLaunch(shortcut)}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-sm transition-all"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>باز کردن</span>
                  </button>

                  <button
                    onClick={() => onShowQR(url, shortcut.title)}
                    className="p-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-300 transition-colors"
                    title={t.showQR}
                  >
                    <QrCode className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
