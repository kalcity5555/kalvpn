import React, { useState } from 'react';
import { Language, PlatformType } from '../types';
import { translations } from '../data/translations';
import { InstagramIcon, WhatsAppIcon, TelegramIcon } from './BrandIcons';
import { ExternalLink, RefreshCw, AlertTriangle, ShieldCheck, Compass } from 'lucide-react';

interface EmbeddedWebViewerProps {
  language: Language;
}

export function EmbeddedWebViewer({ language }: EmbeddedWebViewerProps) {
  const t = translations[language];

  const [activePlatform, setActivePlatform] = useState<PlatformType>('whatsapp');
  const [iframeKey, setIframeKey] = useState(0);

  const platforms = [
    {
      id: 'whatsapp' as PlatformType,
      name: t.whatsapp,
      icon: WhatsAppIcon,
      url: 'https://web.whatsapp.com',
      color: 'text-emerald-400',
      activeBg: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
    },
    {
      id: 'telegram' as PlatformType,
      name: t.telegram,
      icon: TelegramIcon,
      url: 'https://web.telegram.org',
      color: 'text-sky-400',
      activeBg: 'bg-sky-500/10 text-sky-300 border-sky-500/30'
    },
    {
      id: 'instagram' as PlatformType,
      name: t.instagram,
      icon: InstagramIcon,
      url: 'https://instagram.com',
      color: 'text-pink-400',
      activeBg: 'bg-pink-500/10 text-pink-300 border-pink-500/30'
    }
  ];

  const currentPlatform = platforms.find((p) => p.id === activePlatform)!;

  const handleReload = () => {
    setIframeKey((prev) => prev + 1);
  };

  return (
    <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-2xl backdrop-blur-md">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Compass className="w-5 h-5 text-indigo-400" />
            <span>{t.tabWebview}</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            دسترسی مستقیم و یکپارچه به نسخه‌های وب پیام‌رسان‌ها
          </p>
        </div>

        {/* Platform Selector Buttons */}
        <div className="flex items-center gap-2">
          {platforms.map((p) => {
            const Icon = p.icon;
            const isActive = activePlatform === p.id;
            return (
              <button
                key={p.id}
                onClick={() => setActivePlatform(p.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all ${
                  isActive
                    ? p.activeBg
                    : 'bg-slate-800/80 text-slate-400 border-slate-700 hover:text-slate-200'
                }`}
              >
                <Icon className={`w-4 h-4 ${p.color}`} />
                <span>{p.name}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Notice Banner */}
      <div className="bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs p-3 rounded-xl mb-4 flex items-start gap-2.5">
        <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
        <div className="flex-1">
          <p>{t.webviewNotice}</p>
        </div>
        <a
          href={currentPlatform.url}
          target="_blank"
          rel="noopener noreferrer"
          className="shrink-0 flex items-center gap-1 font-bold text-amber-400 hover:underline"
        >
          <span>{t.openNewTab}</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </a>
      </div>

      {/* Web Frame Control Bar */}
      <div className="bg-slate-950 rounded-t-2xl p-3 border border-slate-800 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2 text-slate-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span className="font-mono text-slate-300 dir-ltr">{currentPlatform.url}</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleReload}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            title={t.reload}
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>

          <a
            href={currentPlatform.url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-colors"
          >
            <span>{t.openNewTab}</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>

      {/* Embedded iFrame Container */}
      <div className="w-full h-[600px] bg-slate-950 rounded-b-2xl border-x border-b border-slate-800 relative overflow-hidden">
        <iframe
          key={`${activePlatform}-${iframeKey}`}
          src={currentPlatform.url}
          title={currentPlatform.name}
          className="w-full h-full border-0"
          sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
        />
      </div>

    </div>
  );
}
