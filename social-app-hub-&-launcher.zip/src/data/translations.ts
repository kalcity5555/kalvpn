import { Language } from '../types';

export const translations: Record<Language, Record<string, string>> = {
  fa: {
    appTitle: 'سوشال لانچر',
    appSubtitle: 'دسترسی سریع و مستقیم به اینستاگرام، واتساپ و تلگرام',
    launchApp: 'باز کردن برنامه',
    openWeb: 'نسخه وب',
    openNative: 'اپلیکیشن موبایل',
    directChat: 'چت مستقیم',
    shortcuts: 'میانبرهای من',
    addShortcut: 'افزودن میانبر جدید',
    allPlatforms: 'همه پلتفرم‌ها',
    instagram: 'اینستاگرام',
    whatsapp: 'واتساپ',
    telegram: 'تلگرام',
    
    // WhatsApp direct chat
    waTitle: 'ارسال پیام واتساپ بدون ذخیره شماره',
    waDesc: 'شماره تلفن مخاطب را وارد کنید تا بدون نیاز به ذخیره کردن در مخاطبین، چت واتساپ باز شود.',
    phonePlaceholder: 'مثلا ۰۹۱۲۳۴۵۶۷۸۹ یا ۹۸۹۱۲۳۴۵۶۷۸۹',
    countryCode: 'کد کشور',
    messagePlaceholder: 'متن پیام اختیاری (می‌توانید خالی بگذارید)',
    startChat: 'شروع چت در واتساپ',
    copyLink: 'کپی لینک چت',
    showQR: 'نمایش QR کد',
    
    // Telegram direct
    tgTitle: 'جستجو و باز کردن آیدی تلگرام',
    tgDesc: 'آیدی کاربر، کانال، گروه یا ربات تلگرام را وارد کنید.',
    usernamePlaceholder: 'مثلا my_channel یا username',
    openTelegram: 'باز کردن در تلگرام',
    channelOrUser: 'کاربر / کانال / ربات',
    
    // Instagram direct
    igTitle: 'باز کردن پروفایل اینستاگرام',
    igDesc: 'نام کاربری اینستاگرام را وارد کنید تا مستقیم وارد پروفایل یا استوری شوید.',
    igUserPlaceholder: 'مثلا username',
    openProfile: 'مشاهده پروفایل',
    openReels: 'بخش ریلز (Reels)',
    openExplore: 'اکسپلور',

    // Shortcut Manager
    noShortcuts: 'هنوز هیچ میانبری اضافه نکرده‌اید.',
    shortcutTitle: 'عنوان میانبر',
    shortcutTarget: 'شماره یا آیدی',
    save: 'ذخیره',
    cancel: 'انصراف',
    delete: 'حذف',
    quickAccess: 'دسترسی سریع',

    // Tabs
    tabDashboard: 'داشبورد اصلی',
    tabWhatsapp: 'ابزار واتساپ',
    tabTelegram: 'ابزار تلگرام',
    tabInstagram: 'ابزار اینستاگرام',
    tabShortcuts: 'میانبرها',
    tabWebview: 'نمایشگر وب',

    // Webview
    webviewNotice: 'توجه: برخی سرویس‌ها ممکن است به دلایل امنیتی در فریم داخلی نمایش داده نشوند. در این صورت از دکمه "باز کردن در تب جدید" استفاده کنید.',
    openNewTab: 'باز کردن در تب جدید',
    reload: 'بروزرسانی',

    // Toast & General
    linkCopied: 'لینک با موفقیت کپی شد!',
    savedSuccessfully: 'با موفقیت ذخیره شد.',
    deletedSuccessfully: 'میانبر حذف شد.',
    enterValidInput: 'لطفا مقادیر معتبر وارد کنید.',
    selectCountry: 'انتخاب کشور',
    close: 'بستن',
    recentActivity: 'فعالیت‌های اخیر'
  },
  en: {
    appTitle: 'Social Hub & Launcher',
    appSubtitle: 'Quick & direct access to Instagram, WhatsApp, and Telegram',
    launchApp: 'Open App',
    openWeb: 'Web Version',
    openNative: 'Mobile App',
    directChat: 'Direct Chat',
    shortcuts: 'My Shortcuts',
    addShortcut: 'Add New Shortcut',
    allPlatforms: 'All Platforms',
    instagram: 'Instagram',
    whatsapp: 'WhatsApp',
    telegram: 'Telegram',
    
    // WhatsApp direct chat
    waTitle: 'Send WhatsApp Message Without Saving Number',
    waDesc: 'Enter a phone number to instantly launch a WhatsApp chat without saving it to contacts.',
    phonePlaceholder: 'e.g. +989123456789 or 09123456789',
    countryCode: 'Country Code',
    messagePlaceholder: 'Optional message text...',
    startChat: 'Start WhatsApp Chat',
    copyLink: 'Copy Chat Link',
    showQR: 'Show QR Code',
    
    // Telegram direct
    tgTitle: 'Open Telegram ID & Username',
    tgDesc: 'Enter Telegram username, channel, group or bot ID.',
    usernamePlaceholder: 'e.g. channel_name or username',
    openTelegram: 'Open in Telegram',
    channelOrUser: 'User / Channel / Bot',
    
    // Instagram direct
    igTitle: 'Open Instagram Profile',
    igDesc: 'Enter Instagram username to directly open profile or stories.',
    igUserPlaceholder: 'e.g. username',
    openProfile: 'View Profile',
    openReels: 'Reels Section',
    openExplore: 'Explore Page',

    // Shortcut Manager
    noShortcuts: 'No shortcuts added yet.',
    shortcutTitle: 'Shortcut Title',
    shortcutTarget: 'Phone or Username',
    save: 'Save',
    cancel: 'Cancel',
    delete: 'Delete',
    quickAccess: 'Quick Access',

    // Tabs
    tabDashboard: 'Main Dashboard',
    tabWhatsapp: 'WhatsApp Tool',
    tabTelegram: 'Telegram Tool',
    tabInstagram: 'Instagram Tool',
    tabShortcuts: 'Shortcuts',
    tabWebview: 'Web Viewer',

    // Webview
    webviewNotice: 'Note: Some platforms restrict embedding inside webframes. Use "Open in New Tab" for full experience.',
    openNewTab: 'Open in New Tab',
    reload: 'Reload',

    // Toast & General
    linkCopied: 'Link copied to clipboard!',
    savedSuccessfully: 'Saved successfully.',
    deletedSuccessfully: 'Shortcut deleted.',
    enterValidInput: 'Please enter a valid input.',
    selectCountry: 'Select Country',
    close: 'Close',
    recentActivity: 'Recent Activity'
  }
};

export const countryCodes = [
  { code: '+98', country: 'ایران (Iran)', flag: '🇮🇷', iso: 'IR' },
  { code: '+1', country: 'آمریکا / کانادا (USA/Canada)', flag: '🇺🇸', iso: 'US' },
  { code: '+971', country: 'امارات (UAE)', flag: '🇦🇪', iso: 'AE' },
  { code: '+90', country: 'ترکیه (Turkey)', flag: '🇹🇷', iso: 'TR' },
  { code: '+49', country: 'آلمان (Germany)', flag: '🇩🇪', iso: 'DE' },
  { code: '+44', country: 'انگلیس (UK)', flag: '🇬🇧', iso: 'GB' },
  { code: '+33', country: 'فرانسه (France)', flag: '🇫🇷', iso: 'FR' },
  { code: '+31', country: 'هلند (Netherlands)', flag: '🇳🇱', iso: 'NL' },
  { code: '+61', country: 'استرالیا (Australia)', flag: '🇦🇺', iso: 'AU' },
];
