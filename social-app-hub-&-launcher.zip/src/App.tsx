import React, { useState, useEffect } from 'react';
import { Language, ShortcutItem, PlatformType } from './types';
import { translations } from './data/translations';
import { Header } from './components/Header';
import { AppCard } from './components/AppCard';
import { WhatsAppDirectChat } from './components/WhatsAppDirectChat';
import { TelegramDirect } from './components/TelegramDirect';
import { InstagramDirect } from './components/InstagramDirect';
import { ShortcutManager } from './components/ShortcutManager';
import { EmbeddedWebViewer } from './components/EmbeddedWebViewer';
import { QRCodeModal } from './components/QRCodeModal';
import { InstagramIcon, WhatsAppIcon, TelegramIcon } from './components/BrandIcons';
import { Sparkles, MessageSquare, ShieldCheck, Zap, ArrowLeft, Bookmark, ExternalLink, Globe } from 'lucide-react';

export default function App() {
  const [language, setLanguage] = useState<Language>('fa');
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  
  // Shortcuts state initialized from localStorage
  const [shortcuts, setShortcuts] = useState<ShortcutItem[]>(() => {
    try {
      const saved = localStorage.getItem('social_hub_shortcuts');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [
      { id: '1', title: 'واتساپ پشتیبانی', platform: 'whatsapp', target: '989123456789', note: 'ارسال پیام به پشتیبانی', createdAt: Date.now() },
      { id: '2', title: 'کانال تلگرام خبر', platform: 'telegram', target: 'durov', createdAt: Date.now() },
    ];
  });

  // Toast message state
  const [toast, setToast] = useState<string | null>(null);

  // QR Modal state
  const [qrModal, setQrModal] = useState<{ url: string; title: string } | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('social_hub_shortcuts', JSON.stringify(shortcuts));
    } catch (e) {
      console.error(e);
    }
  }, [shortcuts]);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => {
      setToast(null);
    }, 3000);
  };

  const handleAddShortcut = (shortcut: Omit<ShortcutItem, 'id' | 'createdAt'>) => {
    const newItem: ShortcutItem = {
      ...shortcut,
      id: Date.now().toString(),
      createdAt: Date.now(),
    };
    setShortcuts((prev) => [newItem, ...prev]);
  };

  const handleRemoveShortcut = (id: string) => {
    setShortcuts((prev) => prev.filter((s) => s.id !== id));
  };

  const t = translations[language];

  return (
    <div
      dir={language === 'fa' ? 'rtl' : 'ltr'}
      className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-indigo-500 selection:text-white"
    >
      {/* Background Decorative Blur Gradients */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-pink-600/10 blur-[120px]" />
        <div className="absolute top-[20%] left-[-10%] w-[500px] h-[500px] rounded-full bg-emerald-600/10 blur-[120px]" />
        <div className="absolute bottom-[-10%] left-[30%] w-[500px] h-[500px] rounded-full bg-sky-600/10 blur-[120px]" />
      </div>

      <div className="relative z-10 flex flex-col min-h-screen">
        
        {/* Navigation Header */}
        <Header
          language={language}
          onLanguageChange={setLanguage}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          shortcutCount={shortcuts.length}
        />

        {/* Main Content Body */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
          
          {/* TAB 1: MAIN DASHBOARD */}
          {activeTab === 'dashboard' && (
            <div className="space-y-8">
              
              {/* Hero Banner */}
              <div className="relative rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950/80 to-slate-900 border border-slate-800 p-6 sm:p-8 overflow-hidden shadow-2xl">
                <div className="relative z-10 max-w-2xl">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 mb-3">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>مرکز مدیریت پیام‌رسان‌ها و شبکه‌های اجتماعی</span>
                  </span>
                  <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mb-2">
                    اینستاگرام، واتساپ و تلگرام در یک نگاه
                  </h2>
                  <p className="text-sm text-slate-300 leading-relaxed mb-6">
                    بدون نیاز به ذخیره مخاطبین در واتساپ پیام بفرستید، آیدی‌های تلگرام را در لحظه باز کنید و مستقیم وارد پروفایل‌های اینستاگرام شوید.
                  </p>

                  <div className="flex flex-wrap items-center gap-3">
                    <button
                      onClick={() => setActiveTab('whatsapp')}
                      className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs sm:text-sm shadow-lg shadow-emerald-500/20 transition-all"
                    >
                      <WhatsAppIcon className="w-4 h-4" />
                      <span>چت مستقیم واتساپ</span>
                    </button>

                    <button
                      onClick={() => setActiveTab('telegram')}
                      className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs sm:text-sm shadow-lg shadow-sky-500/20 transition-all"
                    >
                      <TelegramIcon className="w-4 h-4" />
                      <span>جستجوی تلگرام</span>
                    </button>

                    <button
                      onClick={() => setActiveTab('instagram')}
                      className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-rose-500 to-purple-600 hover:opacity-90 text-white font-bold text-xs sm:text-sm shadow-lg shadow-pink-500/20 transition-all"
                    >
                      <InstagramIcon className="w-4 h-4" />
                      <span>اینستاگرام</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* The 3 Core App Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <AppCard
                  platform="whatsapp"
                  language={language}
                  onOpenTool={(p) => setActiveTab(p)}
                />
                <AppCard
                  platform="telegram"
                  language={language}
                  onOpenTool={(p) => setActiveTab(p)}
                />
                <AppCard
                  platform="instagram"
                  language={language}
                  onOpenTool={(p) => setActiveTab(p)}
                />
              </div>

              {/* Direct Quick Chat Tool Widget embedded in Dashboard */}
              <div className="pt-4">
                <WhatsAppDirectChat
                  language={language}
                  onShowQR={(url, title) => setQrModal({ url, title })}
                  onAddShortcut={handleAddShortcut}
                  onShowToast={showToast}
                />
              </div>

            </div>
          )}

          {/* TAB 2: WHATSAPP DIRECT TOOL */}
          {activeTab === 'whatsapp' && (
            <WhatsAppDirectChat
              language={language}
              onShowQR={(url, title) => setQrModal({ url, title })}
              onAddShortcut={handleAddShortcut}
              onShowToast={showToast}
            />
          )}

          {/* TAB 3: TELEGRAM DIRECT TOOL */}
          {activeTab === 'telegram' && (
            <TelegramDirect
              language={language}
              onShowQR={(url, title) => setQrModal({ url, title })}
              onAddShortcut={handleAddShortcut}
              onShowToast={showToast}
            />
          )}

          {/* TAB 4: INSTAGRAM DIRECT TOOL */}
          {activeTab === 'instagram' && (
            <InstagramDirect
              language={language}
              onShowQR={(url, title) => setQrModal({ url, title })}
              onAddShortcut={handleAddShortcut}
              onShowToast={showToast}
            />
          )}

          {/* TAB 5: SHORTCUTS MANAGER */}
          {activeTab === 'shortcuts' && (
            <ShortcutManager
              shortcuts={shortcuts}
              language={language}
              onRemoveShortcut={handleRemoveShortcut}
              onShowQR={(url, title) => setQrModal({ url, title })}
              onShowToast={showToast}
            />
          )}

          {/* TAB 6: EMBEDDED WEB VIEWER */}
          {activeTab === 'webview' && (
            <EmbeddedWebViewer language={language} />
          )}

        </main>

        {/* Footer */}
        <footer className="mt-auto border-t border-slate-900 bg-slate-950/80 py-6 text-center text-xs text-slate-500">
          <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
            <p>
              © {new Date().getFullYear()} Social App Hub & Launcher • دسترسی یکپارچه به پیام‌رسان‌ها
            </p>
            <div className="flex items-center gap-4 text-slate-400">
              <span>Instagram</span>
              <span>•</span>
              <span>WhatsApp</span>
              <span>•</span>
              <span>Telegram</span>
            </div>
          </div>
        </footer>

      </div>

      {/* QR Code Modal */}
      {qrModal && (
        <QRCodeModal
          url={qrModal.url}
          title={qrModal.title}
          onClose={() => setQrModal(null)}
        />
      )}

      {/* Toast Notification Floating Banner */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-indigo-600 text-white px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-2 text-xs font-bold animate-bounce border border-indigo-400">
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>{toast}</span>
        </div>
      )}

    </div>
  );
}
